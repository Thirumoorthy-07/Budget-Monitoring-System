// Global variables
let currentUser = null;
let transactions = [];
let notifications = [];
let currentFilter = 'all';

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    checkAuthStatus();
});

// Initialize event listeners
function initializeEventListeners() {
    // Login/Register forms
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    document.getElementById('registerForm').addEventListener('submit', handleRegister);
    
    // Transaction form
    document.getElementById('transactionForm').addEventListener('submit', handleTransactionSubmit);
    
    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', (e) => filterTransactions(e.target.dataset.filter));
    });
    
    // Notification buttons
    document.getElementById('clearNotificationsBtn').addEventListener('click', clearNotifications);
    
    // Communication buttons
    document.getElementById('sendSmsBtn').addEventListener('click', sendSMSNotification);
    document.getElementById('sendEmailBtn').addEventListener('click', sendEmailNotification);
    
    // Logout button
    document.getElementById('logoutBtn').addEventListener('click', logout);
    
    // Overlay click
    document.getElementById('overlay').addEventListener('click', toggleNotifications);
}

// Authentication functions
function checkAuthStatus() {
    const user = localStorage.getItem('currentUser');
    if (user) {
        currentUser = JSON.parse(user);
        showMainApp();
    } else {
        showLoginPage();
    }
}

function showLoginPage() {
    document.getElementById('loginPage').style.display = 'flex';
    document.getElementById('mainApp').style.display = 'none';
}

function showMainApp() {
    document.getElementById('loginPage').style.display = 'none';
    document.getElementById('mainApp').style.display = 'block';
    
    // Load user-specific data
    loadUserData();
    initializeApp();
}

function switchTab(tab) {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const tabs = document.querySelectorAll('.login-tab');
    
    tabs.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    
    if (tab === 'login') {
        loginForm.style.display = 'block';
        registerForm.style.display = 'none';
    } else {
        loginForm.style.display = 'none';
        registerForm.style.display = 'block';
    }
}

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Check demo credentials or stored users
    if ((email === 'demo@budgetmonitor.com' && password === 'demo123') || 
        validateUser(email, password)) {
        
        currentUser = {
            name: email === 'demo@budgetmonitor.com' ? 'Demo User' : getUserName(email),
            email: email,
            phone: email === 'demo@budgetmonitor.com' ? '+1234567890' : getUserPhone(email)
        };
        
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        showMainApp();
    } else {
        alert('Invalid credentials. Please try again or use demo credentials.');
    }
}

function handleRegister(e) {
    e.preventDefault();
    
    const name = document.getElementById('registerName').value;
    const email = document.getElementById('registerEmail').value;
    const phone = document.getElementById('registerPhone').value;
    const password = document.getElementById('registerPassword').value;
    
    // Store user data
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    
    // Check if user already exists
    if (users.find(u => u.email === email)) {
        alert('User already exists with this email!');
        return;
    }
    
    users.push({ name, email, phone, password });
    localStorage.setItem('registeredUsers', JSON.stringify(users));
    
    alert('Registration successful! Please login with your credentials.');
    switchTab('login');
}

function validateUser(email, password) {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    return users.find(u => u.email === email && u.password === password);
}

function getUserName(email) {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const user = users.find(u => u.email === email);
    return user ? user.name : 'User';
}

function getUserPhone(email) {
    const users = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
    const user = users.find(u => u.email === email);
    return user ? user.phone : '';
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('currentUser');
        currentUser = null;
        showLoginPage();
    }
}

function loadUserData() {
    const userKey = `transactions_${currentUser.email}`;
    const notificationKey = `notifications_${currentUser.email}`;
    
    transactions = JSON.parse(localStorage.getItem(userKey) || '[]');
    notifications = JSON.parse(localStorage.getItem(notificationKey) || '[]');
    
    // Set user name in header
    document.getElementById('userName').textContent = currentUser.name;
    
    // Pre-fill communication fields with user data
    document.getElementById('smsPhone').value = currentUser.phone || '';
    document.getElementById('emailAddress').value = currentUser.email || '';
}

function saveUserData() {
    const userKey = `transactions_${currentUser.email}`;
    const notificationKey = `notifications_${currentUser.email}`;
    
    localStorage.setItem(userKey, JSON.stringify(transactions));
    localStorage.setItem(notificationKey, JSON.stringify(notifications));
}

function initializeApp() {
    // Set today's date as default
    document.getElementById('date').value = new Date().toISOString().split('T')[0];
    
    // Update UI
    updateDashboard();
    renderTransactions();
    updateNotifications();
    
    // Add welcome notification if first time
    if (transactions.length === 0 && notifications.length === 0) {
        addNotification(`Welcome ${currentUser.name}! Start by adding your first transaction.`, 'success');
    }
}

// Transaction functions
function handleTransactionSubmit(e) {
    e.preventDefault();
    
    const description = document.getElementById('description').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const category = document.getElementById('category').value;
    const type = document.getElementById('type').value;
    const date = document.getElementById('date').value;
    
    // Create transaction object
    const transaction = {
        id: Date.now(),
        description,
        amount: type === 'expense' ? -Math.abs(amount) : Math.abs(amount),
        category,
        type,
        date,
        timestamp: new Date().toISOString()
    };
    
    // Add to transactions array
    transactions.unshift(transaction);
    
    // Save to localStorage
    saveUserData();
    
    // Add success notification
    addNotification(`${type === 'income' ? 'Income' : 'Expense'} of ₹${Math.abs(amount)} added successfully!`, 'success');
    
    // Check for low balance warning
    const balance = calculateBalance();
    if (balance < 5000 && balance > 0) {
        addNotification(`Warning: Your balance is low (₹${balance.toFixed(2)}). Consider monitoring your expenses.`, 'warning');
    }
    
    // Reset form
    e.target.reset();
    document.getElementById('date').value = new Date().toISOString().split('T')[0];
    
    // Update UI
    updateDashboard();
    renderTransactions();
    
    // Check for spending patterns
    setTimeout(checkSpendingPatterns, 1000);
}

function calculateBalance() {
    return transactions.reduce((sum, transaction) => sum + transaction.amount, 0);
}

function calculateIncome() {
    return transactions
        .filter(t => t.amount > 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0);
}

function calculateExpenses() {
    return Math.abs(transactions
        .filter(t => t.amount < 0)
        .reduce((sum, transaction) => sum + transaction.amount, 0));
}

function updateDashboard() {
    const balance = calculateBalance();
    const income = calculateIncome();
    const expenses = calculateExpenses();
    
    document.getElementById('totalBalance').textContent = `₹${balance.toFixed(2)}`;
    document.getElementById('totalIncome').textContent = `₹${income.toFixed(2)}`;
    document.getElementById('totalExpenses').textContent = `₹${expenses.toFixed(2)}`;
}

function renderTransactions() {
    const container = document.getElementById('transactionsList');
    let filteredTransactions = transactions;
    
    // Apply filter
    if (currentFilter === 'income') {
        filteredTransactions = transactions.filter(t => t.amount > 0);
    } else if (currentFilter === 'expense') {
        filteredTransactions = transactions.filter(t => t.amount < 0);
    }
    
    if (filteredTransactions.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-receipt"></i>
                <p>No ${currentFilter === 'all' ? '' : currentFilter} transactions found.</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = filteredTransactions.map(transaction => `
        <div class="transaction-item">
            <div class="transaction-info">
                <div class="transaction-description">${transaction.description}</div>
                <div class="transaction-meta">
                    ${transaction.category} • ${new Date(transaction.date).toLocaleDateString()}
                </div>
            </div>
            <div class="transaction-amount ${transaction.amount > 0 ? 'amount-positive' : 'amount-negative'}">
                ${transaction.amount > 0 ? '+' : ''}₹${Math.abs(transaction.amount).toFixed(2)}
            </div>
            <button class="btn btn-danger" onclick="deleteTransaction(${transaction.id})">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}

function filterTransactions(filter) {
    currentFilter = filter;
    
    // Update active button
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    renderTransactions();
}

function deleteTransaction(id) {
    if (confirm('Are you sure you want to delete this transaction?')) {
        transactions = transactions.filter(t => t.id !== id);
        saveUserData();
        
        addNotification('Transaction deleted successfully!', 'success');
        updateDashboard();
        renderTransactions();
    }
}

// Notification functions
function addNotification(message, type = 'info') {
    const notification = {
        id: Date.now(),
        message,
        type,
        timestamp: new Date().toISOString(),
        read: false
    };
    
    notifications.unshift(notification);
    saveUserData();
    updateNotifications();
}

function updateNotifications() {
    const badge = document.getElementById('notificationBadge');
    const unreadCount = notifications.filter(n => !n.read).length;
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    
    renderNotifications();
}

function renderNotifications() {
    const container = document.getElementById('notificationsList');
    
    if (notifications.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-bell-slash"></i>
                <p>No notifications yet</p>
            </div>
        `;
        return;
    }
    
    container.innerHTML = notifications.map(notification => `
        <div class="notification-item ${notification.type}">
            <div style="font-weight: 600; margin-bottom: 5px;">${notification.message}</div>
            <div style="font-size: 0.8rem; color: #636e72;">
                ${new Date(notification.timestamp).toLocaleString()}
            </div>
        </div>
    `).join('');
}

function toggleNotifications() {
    const panel = document.getElementById('notificationPanel');
    const overlay = document.getElementById('overlay');
    
    panel.classList.toggle('open');
    overlay.classList.toggle('show');
    
    // Mark all as read when opened
    if (panel.classList.contains('open')) {
        notifications.forEach(n => n.read = true);
        saveUserData();
        updateNotifications();
    }
}

function clearNotifications() {
    if (confirm('Are you sure you want to clear all notifications?')) {
        notifications = [];
        saveUserData();
        updateNotifications();
    }
}

// Communication functions
function sendSMSNotification() {
    const phoneNumber = document.getElementById('smsPhone').value;
    const resultDiv = document.getElementById('smsResult');
    
    if (!phoneNumber) {
        resultDiv.innerHTML = '<div class="error-message">Please enter a phone number</div>';
        return;
    }
    
    const balance = calculateBalance();
    const income = calculateIncome();
    const expenses = calculateExpenses();
    
    const message = `Budget Summary for ${currentUser.name}:\n\nBalance: ₹${balance.toFixed(2)}\nIncome: ₹${income.toFixed(2)}\nExpenses: ₹${expenses.toFixed(2)}\n\nDate: ${new Date().toLocaleDateString()}\n\nSent from Budget Monitor`;
    
    // Simulate SMS sending with EmailJS or similar service
    // In a real application, you would integrate with Twilio, AWS SNS, or similar SMS service
    
    // For demo purposes, we'll simulate the SMS sending
    resultDiv.innerHTML = '<div style="color: #666; margin-top: 10px;"><i class="fas fa-spinner fa-spin"></i> Sending SMS...</div>';
    
    setTimeout(() => {
        resultDiv.innerHTML = `
            <div class="success-message">
                <i class="fas fa-check-circle"></i> SMS sent successfully to ${phoneNumber}!
                <br><br>
                <strong>Message Preview:</strong><br>
                <div style="background: #f8f9fa; padding: 10px; border-radius: 5px; margin-top: 10px; font-family: monospace; font-size: 0.9rem;">
                    ${message.replace(/\n/g, '<br>')}
                </div>
            </div>
        `;
        
        addNotification(`Expense summary sent via SMS to ${phoneNumber}`, 'success');
    }, 2000);
}

function sendEmailNotification() {
    const emailAddress = document.getElementById('emailAddress').value;
    const resultDiv = document.getElementById('emailResult');
    
    if (!emailAddress) {
        resultDiv.innerHTML = '<div class="error-message">Please enter an email address</div>';
        return;
    }
    
    const balance = calculateBalance();
    const income = calculateIncome();
    const expenses = calculateExpenses();
    
    // Create detailed email content
    const emailContent = {
        to: emailAddress,
        subject: `Budget Report - ${new Date().toLocaleDateString()}`,
        body: `
            <h2>Budget Report for ${currentUser.name}</h2>
            <p>Here's your financial summary as of ${new Date().toLocaleDateString()}:</p>
            
            <div style="background: #f8f9fa; padding: 20px; border-radius: 10px; margin: 20px 0;">
                <h3>Financial Overview</h3>
                <p><strong>Current Balance:</strong> ₹${balance.toFixed(2)}</p>
                <p><strong>Total Income:</strong> ₹${income.toFixed(2)}</p>
                <p><strong>Total Expenses:</strong> ₹${expenses.toFixed(2)}</p>
            </div>
            
            <h3>Recent Transactions</h3>
            ${generateTransactionTable()}
            
            <p style="margin-top: 30px; color: #666;">
                This report was generated automatically by Budget Monitor.<br>
                Generated on: ${new Date().toLocaleString()}
            </p>
        `
    };
    
    // Simulate email sending
    resultDiv.innerHTML = '<div style="color: #666; margin-top: 10px;"><i class="fas fa-spinner fa-spin"></i> Sending email...</div>';
    
    setTimeout(() => {
        resultDiv.innerHTML = `
            <div class="success-message">
                <i class="fas fa-check-circle"></i> Budget report sent successfully to ${emailAddress}!
                <br><br>
                <strong>Email Preview:</strong><br>
                <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin-top: 10px; max-height: 200px; overflow-y: auto;">
                    <strong>To:</strong> ${emailAddress}<br>
                    <strong>Subject:</strong> ${emailContent.subject}<br><br>
                    ${emailContent.body}
                </div>
            </div>
        `;
        
        addNotification(`Budget report sent via email to ${emailAddress}`, 'success');
    }, 2500);
}

function generateTransactionTable() {
    const recentTransactions = transactions.slice(0, 10);
    
    if (recentTransactions.length === 0) {
        return '<p>No transactions to display.</p>';
    }
    
    let table = `
        <table style="width: 100%; border-collapse: collapse; margin: 10px 0;">
            <thead>
                <tr style="background: #6c5ce7; color: white;">
                    <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Date</th>
                    <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Description</th>
                    <th style="padding: 10px; text-align: left; border: 1px solid #ddd;">Category</th>
                    <th style="padding: 10px; text-align: right; border: 1px solid #ddd;">Amount</th>
                </tr>
            </thead>
            <tbody>
    `;
    
    recentTransactions.forEach(transaction => {
        const amountColor = transaction.amount > 0 ? '#00b894' : '#e17055';
        table += `
            <tr>
                <td style="padding: 8px; border: 1px solid #ddd;">${new Date(transaction.date).toLocaleDateString()}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${transaction.description}</td>
                <td style="padding: 8px; border: 1px solid #ddd;">${transaction.category}</td>
                <td style="padding: 8px; border: 1px solid #ddd; text-align: right; color: ${amountColor}; font-weight: bold;">
                    ${transaction.amount > 0 ? '+' : ''}₹${Math.abs(transaction.amount).toFixed(2)}
                </td>
            </tr>
        `;
    });
    
    table += '</tbody></table>';
    return table;
}

// Check for unusual spending patterns
function checkSpendingPatterns() {
    const recentExpenses = transactions
        .filter(t => t.amount < 0)
        .slice(0, 5);
    
    if (recentExpenses.length >= 3) {
        const avgExpense = recentExpenses.reduce((sum, t) => sum + Math.abs(t.amount), 0) / recentExpenses.length;
        const lastExpense = Math.abs(recentExpenses[0].amount);
        
        if (lastExpense > avgExpense * 2) {
            addNotification(`Unusual spending detected: ₹${lastExpense.toFixed(2)} is significantly higher than your average.`, 'warning');
        }
    }
}